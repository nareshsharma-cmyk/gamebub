"""
╔══════════════════════════════════════════════════════════════════════╗
║   FaceButtonArray — Text File → build123d + OCP CAD Viewer          ║
╠══════════════════════════════════════════════════════════════════════╣
║  SETUP (one-time)                                                   ║
║    pip install build123d ocp-vscode                                 ║
║    VS Code extension → "OCP CAD Viewer" by bernhard-42             ║
║                                                                     ║
║  RUN                                                                ║
║    python FaceButtonArray_from_txt.py                               ║
║                                                                     ║
║  OUTPUT (saved next to this script)                                 ║
║    FaceButtonArray_rebuilt.stl                                      ║
║    FaceButtonArray_rebuilt.step                                     ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import sys

# ── build123d / OCP ──────────────────────────────────────────────────
from build123d import Shape, export_stl, export_step, import_stl

from OCP.gp             import gp_Pnt
from OCP.BRep           import BRep_Builder
from OCP.BRepBuilderAPI import (BRepBuilderAPI_MakePolygon,
                                BRepBuilderAPI_MakeFace,
                                BRepBuilderAPI_Sewing)
from OCP.TopoDS         import TopoDS_Compound

try:
    from ocp_vscode import Camera, set_defaults, show
    OCP_AVAILABLE = True
except ImportError:
    print("⚠  ocp_vscode not installed — viewer disabled.")
    print("   Run:  pip install ocp-vscode")
    OCP_AVAILABLE = False


# ══════════════════════════════════════════════════════════════════════
#  PATHS
# ══════════════════════════════════════════════════════════════════════

TXT_FILE = (
    sys.argv[1] if len(sys.argv) > 1
    else "/Users/softage/Desktop/gamebub_files/component files/"
         "FaceButtonArray/FaceButtonArray_vertices_triangles.txt"
)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
STL_OUT    = os.path.join(SCRIPT_DIR, "FaceButtonArray_rebuilt.stl")
STEP_OUT   = os.path.join(SCRIPT_DIR, "FaceButtonArray_rebuilt.step")


# ══════════════════════════════════════════════════════════════════════
#  STEP 1 — PARSE TEXT FILE
# ══════════════════════════════════════════════════════════════════════

def parse_txt(path: str):
    """
    Parse the custom vertices-and-triangles text file.

    Section 1 — vertex lines:
        <id>   <x>   <y>   <z>
        e.g.:  0   67.442307   -2.153074   53.266224

    Section 2 — triangle blocks:
        <tri_id>  <v0_id>  <v1_id>  <v2_id>  (+nx, +ny, +nz)
        (+v0_x, +v0_y, +v0_z)
        (+v1_x, +v1_y, +v1_z)
        (+v2_x, +v2_y, +v2_z)

    Returns
    -------
    vertices  : dict  { id: (x, y, z) }
    triangles : list  [ (v0_id, v1_id, v2_id), ... ]
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Text file not found:\n  {path}")

    vertices  = {}
    triangles = []
    in_sec1   = False
    in_sec2   = False

    with open(path, encoding="utf-8") as f:
        lines = f.readlines()

    i = 0
    while i < len(lines):
        line = lines[i].strip()

        # Section markers
        if "SECTION 1" in line:
            in_sec1, in_sec2 = True, False
            i += 1
            continue
        if "SECTION 2" in line:
            in_sec2, in_sec1 = True, False
            i += 1
            continue

        # Skip decorators and blank lines
        if (not line
                or line.startswith("=")
                or line.startswith("-")
                or line.upper().startswith("ID")
                or line.upper().startswith("TRI")
                or line.upper().startswith("V0")
                or line.upper().startswith("END")):
            i += 1
            continue

        # ── Section 1 : vertex line ───────────────────────────────────
        if in_sec1:
            parts = line.split()
            if len(parts) == 4:
                try:
                    vid = int(parts[0])
                    vertices[vid] = (
                        float(parts[1]),
                        float(parts[2]),
                        float(parts[3]),
                    )
                except ValueError:
                    pass

        # ── Section 2 : triangle header line ─────────────────────────
        elif in_sec2:
            m = re.match(
                r'^(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+\([^)]+\)', line)
            if m:
                triangles.append((
                    int(m.group(2)),
                    int(m.group(3)),
                    int(m.group(4)),
                ))

        i += 1

    return vertices, triangles


# ══════════════════════════════════════════════════════════════════════
#  STEP 2 — BUILD OCP SHELL  (triangle soup → sewn BRep shell)
# ══════════════════════════════════════════════════════════════════════

def build_shell(vertices: dict, triangles: list) -> Shape:
    """
    Convert every triangle into a planar BRep face, then sew all faces
    into a topological Shell using BRepBuilderAPI_Sewing.

    The result is wrapped in a TopoDS_Compound → build123d Shape so that
    export_stl / export_step / show() all work correctly.
    """
    sewing  = BRepBuilderAPI_Sewing(1e-3)   # 0.001 mm tolerance
    skipped = 0
    total   = len(triangles)

    for idx, (i0, i1, i2) in enumerate(triangles):

        try:
            # ── Skip degenerate (zero-area) triangles ─────────────────
            ax, ay, az = vertices[i0]
            bx, by, bz = vertices[i1]
            cx, cy, cz = vertices[i2]

            # Cross product magnitude²
            ex, ey, ez = bx-ax, by-ay, bz-az
            fx, fy, fz = cx-ax, cy-ay, cz-az
            cross_sq = ((ey*fz - ez*fy)**2 +
                        (ez*fx - ex*fz)**2 +
                        (ex*fy - ey*fx)**2)
            if cross_sq < 1e-20:
                skipped += 1
                continue

            # ── Build closed triangular wire ──────────────────────────
            p0 = gp_Pnt(ax, ay, az)
            p1 = gp_Pnt(bx, by, bz)
            p2 = gp_Pnt(cx, cy, cz)

            poly = BRepBuilderAPI_MakePolygon()
            poly.Add(p0)
            poly.Add(p1)
            poly.Add(p2)
            poly.Close()
            if not poly.IsDone():
                skipped += 1
                continue

            # ── Build planar face from wire ───────────────────────────
            face_mk = BRepBuilderAPI_MakeFace(poly.Wire())
            if not face_mk.IsDone():
                skipped += 1
                continue

            sewing.Add(face_mk.Face())

        except Exception:
            skipped += 1
            continue

        # Progress every 2 000 triangles
        if (idx + 1) % 2000 == 0:
            pct = (idx + 1) / total * 100
            print(f"    {idx+1:>7,} / {total:,}  ({pct:.1f}%)")

    if skipped:
        print(f"  ⚠  Skipped {skipped:,} degenerate / invalid triangles")

    # ── Sew all faces into a shell ────────────────────────────────────
    print("  Sewing faces into shell …")
    sewing.Perform()
    sewn = sewing.SewedShape()

    # Wrap in a Compound so build123d handles any topology type cleanly
    builder  = BRep_Builder()
    compound = TopoDS_Compound()
    builder.MakeCompound(compound)
    builder.Add(compound, sewn)

    return Shape(compound)


# ══════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════

def main():
    print()
    print("┌" + "─" * 62 + "┐")
    print("│   FaceButtonArray  —  Text File → build123d Geometry     │")
    print("└" + "─" * 62 + "┘")
    print(f"  Input  : {TXT_FILE}")
    print(f"  STL    : {STL_OUT}")
    print(f"  STEP   : {STEP_OUT}")
    print()

    # ── 1. Parse ──────────────────────────────────────────────────────
    print("[ 1 / 4 ]  Parsing text file …")
    vertices, triangles = parse_txt(TXT_FILE)

    n_v = len(vertices)
    n_t = len(triangles)
    xs  = [v[0] for v in vertices.values()]
    ys  = [v[1] for v in vertices.values()]
    zs  = [v[2] for v in vertices.values()]

    print(f"  Vertices  : {n_v:,}")
    print(f"  Triangles : {n_t:,}")
    print(f"  Bbox X    : {min(xs):.4f}  →  {max(xs):.4f}"
          f"  (span {max(xs)-min(xs):.4f})")
    print(f"  Bbox Y    : {min(ys):.4f}  →  {max(ys):.4f}"
          f"  (span {max(ys)-min(ys):.4f})")
    print(f"  Bbox Z    : {min(zs):.4f}  →  {max(zs):.4f}"
          f"  (span {max(zs)-min(zs):.4f})")
    print()

    # ── 2. Build ──────────────────────────────────────────────────────
    print("[ 2 / 4 ]  Building BRep shell from triangles …")
    shape = build_shell(vertices, triangles)
    bb    = shape.bounding_box()

    print(f"  ✓  Shell built")
    print(f"  Bounding box (build123d):")
    print(f"    X : {bb.min.X:+.4f}  →  {bb.max.X:+.4f}"
          f"   span = {bb.max.X - bb.min.X:.4f}")
    print(f"    Y : {bb.min.Y:+.4f}  →  {bb.max.Y:+.4f}"
          f"   span = {bb.max.Y - bb.min.Y:.4f}")
    print(f"    Z : {bb.min.Z:+.4f}  →  {bb.max.Z:+.4f}"
          f"   span = {bb.max.Z - bb.min.Z:.4f}")
    print()

    # ── 3. Export STL + STEP ──────────────────────────────────────────
    print("[ 3 / 4 ]  Exporting …")
    export_stl(shape, STL_OUT,  tolerance=0.01, angular_tolerance=0.3)
    export_step(shape, STEP_OUT)
    print(f"  ✓  {os.path.basename(STL_OUT):<44}"
          f"  {os.path.getsize(STL_OUT)  / 1024:6.1f} KB")
    print(f"  ✓  {os.path.basename(STEP_OUT):<44}"
          f"  {os.path.getsize(STEP_OUT) / 1024:6.1f} KB")
    print()

    # ── 4. OCP CAD Viewer ─────────────────────────────────────────────
    print("[ 4 / 4 ]  Launching OCP CAD Viewer …")
    if OCP_AVAILABLE:
        try:
            # Re-import the exported STL — this gives a fully tessellated
            # build123d mesh with correct normals that the viewer renders
            # reliably (raw Shape(compound) may not display in some versions)
            print("  Re-importing STL for viewer …")
            mesh = import_stl(STL_OUT)

            set_defaults(theme="dark", ortho=False)
            show(
                mesh,
                names         = ["FaceButtonArray"],
                colors        = ["#e07b39"],   # warm orange
                alphas        = [1.0],
                axes          = True,
                axes0         = True,
                grid          = (True, True, True),
                measure_tools = True,
                reset_camera  = Camera.RESET,
            )
            print("  ✅  Showing in OCP CAD Viewer — check VS Code side panel")

        except Exception as e:
            print(f"  ⚠  Viewer error: {e}")
            # Fallback: send the raw compound shape
            try:
                print("  Trying fallback display (raw shape) …")
                show(
                    shape,
                    names        = ["FaceButtonArray"],
                    reset_camera = Camera.RESET,
                )
                print("  ✅  Fallback display sent")
            except Exception as e2:
                print(f"  ⚠  Fallback also failed: {e2}")
    else:
        print("  Skipped — run:  pip install ocp-vscode")

    print()
    print("┌" + "─" * 62 + "┐")
    print(f"│  Done!  {n_t:,} triangles  |  {n_v:,} vertices               │")
    print(f"│  STL  → {os.path.basename(STL_OUT):<52} │")
    print("│  Open in: MeshLab · Blender · PrusaSlicer · viewstl.com │")
    print("└" + "─" * 62 + "┘")


if __name__ == "__main__":
    main()